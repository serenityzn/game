class Test
	def initialize
		@x=1
		@y=1
	end
end


a = Test.new()
puts a.@x
